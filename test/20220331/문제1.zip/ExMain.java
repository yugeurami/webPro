package com.test;

public class ExMain {
	public static void main(String[] args) {

	      Person p = new Person("홍길동", "010-9999-9999");

	      System.out.println(p);

	}

}
